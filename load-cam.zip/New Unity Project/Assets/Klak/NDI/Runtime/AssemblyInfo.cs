// KlakNDI - NDI plugin for Unity
// https://github.com/keijiro/KlakNDI

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Klak.Ndi.Editor")]
