﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hmm : MonoBehaviour
{
    WebCamTexture cam;

    public void pindah(WebCamTexture tex)
    {
        if (cam != null)
        {
            cam.Stop();
            cam = tex;
            gameObject.GetComponent<MeshRenderer>().material.mainTexture = tex;
            cam.Play();
        }
        else
        {
            cam = tex;
            gameObject.GetComponent<MeshRenderer>().material.mainTexture = tex;
            cam.Play();
        }
    }
}
