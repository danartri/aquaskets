﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class tes : MonoBehaviour
{
    WebCamTexture cam;
    WebCamDevice device;
    public List<string> kamera = new List<string>();
    public Dropdown dropdown;

    public GameObject objNow;
    public GameObject[] objs;
    public List<string> objName = new List<string>();

    void Start()
    {
        objs = GameObject.FindGameObjectsWithTag("tex");
        for (int i = 0; i < WebCamTexture.devices.Length; i++)
        {
            device = WebCamTexture.devices[i];
            kamera.Add(device.name);
        }
        dropdown.AddOptions(kamera);
        dropdown.gameObject.SetActive(false);

        foreach (GameObject obj in objs)
        {
            objName.Add("");
        }
    }
    public void ganti(int index)
    {
        device = WebCamTexture.devices[index];
        cam = new WebCamTexture(device.name);

        int hitung = 0;
        foreach (GameObject obj in objs)
        {
            if (objName[hitung] == "")
            {
                if (objNow.name == obj.name)
                {
                    objName[hitung] = device.name;
                    objNow.GetComponent<hmm>().pindah(cam);
                }
            }
            else
            {
                if (objNow.name != obj.name)
                {
                    if (objName[hitung] == device.name)
                    {
                        obj.GetComponent<hmm>().pindah(cam);
                    }
                    else
                    {
                        WebCamTexture aaa = new WebCamTexture(objName[hitung]);
                        obj.GetComponent<hmm>().pindah(aaa);
                    }
                }
                else
                {
                    objName[hitung] = device.name;
                    objNow.GetComponent<hmm>().pindah(cam);
                }
            }
            hitung++;
        }
        dropdown.gameObject.SetActive(false);
    }

    void Update()
    {

        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.transform.tag == "tex")
                {
                    dropdown.gameObject.SetActive(true);
                    objNow = hit.collider.gameObject;
                }
            }
        }

    }
}
